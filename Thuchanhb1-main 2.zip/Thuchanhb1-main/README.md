# VÕ NGUYỄN BÁCH
## MSV: 22810310239

## Kết Quả:
![](./assets/KQ1.jpg)
![](./assets/KQ2.jpg)
![](./assets/KQ3.jpg)
![](./assets/KQ4.jpg)
![](./assets/KQ5.jpg)
